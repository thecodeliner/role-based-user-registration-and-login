<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Role Based Registration</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    
    <?php echo $__env->yieldContent('content'); ?>
    
   
    </body>
</html><?php /**PATH /home/codelin1/public_html/subdomains/file.codeliner.art/resources/views/layouts/app.blade.php ENDPATH**/ ?>